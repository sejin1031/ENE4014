proc (f) (iszero (f f))
