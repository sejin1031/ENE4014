proc (f) proc (x) ((f 3) - (f x))
