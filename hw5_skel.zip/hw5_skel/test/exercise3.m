let p = iszero 1 in
  if p then 88 else 99
