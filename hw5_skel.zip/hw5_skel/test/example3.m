let x = iszero 1 in
  if x then (x-1) else 0
