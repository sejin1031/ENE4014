let x = read in
  proc (y) (x + y)
