(proc (f) (f (f 77)) proc (x) (x-11))
