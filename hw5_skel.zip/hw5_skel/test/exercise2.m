let f = proc (z) z in 
  proc (x) ((f x) - 1)
