let x = read in
  let y = read in
    let quotient = x/y in
    (x-(y*quotient))
