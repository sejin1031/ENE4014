let x := 5 in
let y := 10 in
print ((x - 2) * 4 + y / 5)
