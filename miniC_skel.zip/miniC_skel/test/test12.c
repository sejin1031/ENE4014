let r := {fst := true, snd := 5 } in 
print (r.snd)
