 let i := 0 in
   let sum := 0 in
    while (i <= 10) {
      (sum := sum + i);
      (i := i + 1);
    };
    print (sum)
  

