let x := 1 in
let y := 2 in
(x:= true);
x + y

