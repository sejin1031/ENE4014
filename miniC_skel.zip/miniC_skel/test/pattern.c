 let x := 0 in
   let i:= 1 in
     let r := 0 in
      read(x);
        while(i<=x){
	  (r := r*10);
	  (r := r+i);
	  print(r);
	  (i := i+1)
	};
    
  


