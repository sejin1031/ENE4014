if (3 <= 5) { 
  print(1);
  if (! false) { 
    print(11);
    if (20 <= 10) { 
      print(111)
	}
    else { 
      print(222)
	}
  }
  else {
    print(22)
  }
}
else
{ skip }

